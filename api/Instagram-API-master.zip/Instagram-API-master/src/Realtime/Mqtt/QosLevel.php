<?php

namespace InstagramAPI\Realtime\Mqtt;

class QosLevel
{
    const FIRE_AND_FORGET = 0;
    const ACKNOWLEDGED_DELIVERY = 1;
}
